using System;
using TechTalk.SpecFlow;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;

namespace CarKeyDemo
{


    [Binding]
    
    public class Feature1StepDefinitions

    {
        IwebDriver webDriver;
        

        [When(@"User validate car key ""([^""]*)""")]
        
        public void WhenUserValidateCarKey(string ValidateKey)
        {
            

        }

        [Given(@"ValidateKey")]
        public void GivenValidateKey()
        {
            string tab = webDriver.Title;
            Assert.IsTrue(tab.Contains("ValidateKey"), "Valid Key");
        }

        [Given(@"InvalidateKey")]
        public void GivenInvalidateKey()
        {
            //string tab = webDriver.Title;
            //Assert.IsTrue(tab.Contains("Invalid"), "NotValid");
        }

        [Given(@"Fail")]
        public void GivenFail()
        {
            //string tab = webDriver.Title;
            //Assert.IsTrue(tab.Contains("fail"), "NotValid");
        }

        [Given(@"False")]
        public void GivenFalse()
        {
            //string tab = webDriver.Title;
            //Assert.IsTrue(tab.Contains("False"), "NotValid");
        }

        [Then(@"End")]
        public void ThenEnd()
        {
            
        }
    }
}
