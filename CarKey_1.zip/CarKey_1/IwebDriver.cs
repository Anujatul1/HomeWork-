﻿namespace CarKeyDemo
{
    internal class IwebDriver
    {
        public string Title { get; internal set; }
    }
}