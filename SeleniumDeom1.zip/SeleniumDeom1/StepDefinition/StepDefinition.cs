﻿using System;
using TechTalk.SpecFlow;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;




namespace SeleniumDemoTest
{
    [Binding]
    public class Feature1StepDefinitions
    {
        IWebDriver webDriver;
        private string identifier;
        private double expectedvalue;


        [Given(@"User navigates to url ""(.*)""")]

        public void GivenUserNavigatesToUrl(string url)
        {
            webDriver = new ChromeDriver();
            webDriver.Manage().Window.Maximize();
            webDriver.Navigate().GoToUrl(url);
            webDriver.FindElement(By.Name("q")).SendKeys("Tesla");
            webDriver.FindElement(By.XPath("//img[@alt='Google']")).Click();

            System.Threading.Thread.Sleep(5000);
            webDriver.FindElement(By.XPath("(//input[@name='btnI'])[2]")).Click();
            System.Threading.Thread.Sleep(5000);
            string tab = webDriver.Title;
            Assert.IsTrue(tab.Contains("Clean Energy"), "Content not found");
            //div[@class='FPdoLc VlcLAe']//input[@type='submit' and @value= 'Google Search'].


        }

        [When(@"User input text ""(.*)"" on ""(.*)""")]
        public void WhenUserInputTextOn(string Text, string identifier)
        {
            IWebElement webElement = webDriver.FindElement(By.XPath(identifier));
            webElement.SendKeys(Text);
        }

        [When(@"User clicks on ""(.*)""")]
        public void WhenUserClicksOn(string identifier)
        {
            IWebElement webElement = webDriver.FindElement(By.XPath(identifier));
            webElement.Click();
        }

        [Then(@"User verify value of ""(.*)"" is ""(.*)""")]
        public void ThenUserVerifyValueOfIs(string idetifier, string expectedvalue)
        {
            IWebElement webElement = webDriver.FindElement(By.XPath(identifier));
            Assert.AreEqual(expectedvalue, webElement.Text);
        }

        [Then(@"User closes the browser")]
        public void ThenUserClosesTheBrowser()
        {
            webDriver.Close();
        }
    }
}
