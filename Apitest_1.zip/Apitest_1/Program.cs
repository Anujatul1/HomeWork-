﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

using System.Net.Http;
using System.Net.Http.Headers;
using ConsoleProgram;


namespace ConsoleApp8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            class1 class1 = new class1();
            DataObject dataOfUser = class1.Apicall();
            Console.WriteLine(dataOfUser.id);
            Console.WriteLine(dataOfUser.name);
            Console.WriteLine(dataOfUser.email);
            Console.WriteLine(dataOfUser.gender);
            Console.WriteLine(dataOfUser.status);



        }
    }
}



namespace ConsoleProgram
{
    public class DataObject
    {
        public int id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string gender { get; set; }
        public string status { get; set; }

    }

    public class class1
    {
        public DataObject Apicall()
        {
            DataObject dataObject = new DataObject();
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://gorest.co.in");
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/public/v2/users/82").Result;
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                dataObject = JsonConvert.DeserializeObject<DataObject>(result);

            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
            client.Dispose();
            return dataObject;




        }
    }
}




