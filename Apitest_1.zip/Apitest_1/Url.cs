﻿using System;

namespace ConsoleApp8
{
    internal class Url : Uri
    {
        public Url(string uriString) : base(uriString)
        {
        }
    }
}